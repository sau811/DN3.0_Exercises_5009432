package com.employeemanagement.model;

public @interface NamedQueries {

}
